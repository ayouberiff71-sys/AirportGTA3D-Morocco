'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const { randomUUID } = require('crypto');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = Number(process.env.PORT || 8080);
const rooms = new Map();
let server;
if (process.env.TLS_KEY && process.env.TLS_CERT) {
  server = https.createServer({ key: fs.readFileSync(process.env.TLS_KEY), cert: fs.readFileSync(process.env.TLS_CERT) }, health);
  console.log('TLS enabled');
} else {
  server = http.createServer(health);
  console.warn('TLS is not configured. Put this server behind a TLS reverse proxy before using wss:// from Android.');
}
function health(req, res) {
  if (req.url === '/health') { res.writeHead(200, {'content-type':'application/json'}); res.end(JSON.stringify({ok:true,rooms:rooms.size})); return; }
  res.writeHead(200, {'content-type':'text/plain'}); res.end('Airport GTA 3D Morocco multiplayer server');
}
const wss = new WebSocketServer({ server, maxPayload: 2048 });
function send(ws, obj) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function leave(ws) {
  if (!ws.room) return;
  const room = rooms.get(ws.room);
  if (room) { room.delete(ws.id); if (!room.size) rooms.delete(ws.room); }
  ws.room = null;
}
function broadcast(roomName) {
  const room = rooms.get(roomName); if (!room) return;
  const players = [...room.values()].map(p => ({id:p.id,name:p.name,x:p.x,z:p.z,r:p.r,vehicle:p.vehicle}));
  const packet = JSON.stringify({type:'state',players});
  for (const p of room.values()) if (p.readyState === WebSocket.OPEN) p.send(packet);
}
wss.on('connection', ws => {
  ws.id = randomUUID(); ws.room = null; ws.lastMessageAt = 0; ws.messageCount = 0;
  send(ws, {type:'connected',id:ws.id});
  ws.on('message', raw => {
    const now = Date.now();
    if (now - ws.lastMessageAt > 1000) { ws.lastMessageAt = now; ws.messageCount = 0; }
    if (++ws.messageCount > 35) return ws.close(1008, 'rate limit');
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.type === 'join') {
      const roomName = String(msg.room || '').trim().replace(/[^a-zA-Z0-9_-]/g,'').slice(0,20);
      if (!roomName) return send(ws, {type:'error',message:'invalid room'});
      leave(ws);
      if (!rooms.has(roomName)) rooms.set(roomName, new Map());
      ws.room = roomName; ws.name = String(msg.name || 'Player').slice(0,24);
      ws.x = 0; ws.z = 30; ws.r = 0; ws.vehicle = false;
      rooms.get(roomName).set(ws.id, ws);
      send(ws, {type:'welcome',id:ws.id,room:roomName}); broadcast(roomName);
    } else if (msg.type === 'move' && ws.room) {
      ws.x = Math.max(-120, Math.min(120, Number(msg.x) || 0));
      ws.z = Math.max(-100, Math.min(300, Number(msg.z) || 0));
      ws.r = Number.isFinite(Number(msg.r)) ? Number(msg.r) : 0;
      ws.vehicle = !!msg.vehicle;
    }
  });
  ws.on('close', () => { const room = ws.room; leave(ws); if (room) broadcast(room); });
});
setInterval(() => { for (const roomName of rooms.keys()) broadcast(roomName); }, 100);
server.listen(PORT, '0.0.0.0', () => console.log(`Multiplayer server listening on ${PORT}`));
